#!/usr/bin/env bash
set -e
echo "بازار من - آماده سازی و ساخت APK"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK پیدا نشد."
  exit 1
fi

flutter create . --platforms=android --org com.bazaar.man
flutter pub get
flutter build apk --release

echo
echo "APK ساخته شد:"
echo "build/app/outputs/flutter-apk/app-release.apk"
