# ساخت APK برای «بازار من»

## روش ۱ — Android Studio
1. Flutter SDK و Android Studio را نصب کنید.
2. Flutter و Dart plugin را در Android Studio فعال کنید.
3. این پوشه را در Android Studio باز کنید.
4. در Terminal داخل پوشه پروژه اجرا کنید:
   flutter create . --platforms=android --org com.bazaar.man
   flutter pub get
   flutter build apk --release
5. فایل نهایی در این مسیر ساخته می‌شود:
   build/app/outputs/flutter-apk/app-release.apk

برای نصب روی گوشی، فایل APK را به گوشی منتقل کنید و آن را باز کنید.

## روش ۲ — GitHub Actions
این پروژه فایل .github/workflows/build-apk.yml دارد.
پروژه را در GitHub قرار دهید، سپس:
Actions → Build بازار من APK → Run workflow
را اجرا کنید.

بعد از پایان، از بخش Artifacts فایل bazaar-man-release-apk را دریافت کنید و APK داخل آن را روی گوشی نصب کنید.

## وضعیت پروژه
این نسخه Prototype است. پرداخت واقعی، سرور، دیتابیس، ورود کاربران، پنل مدیریت و سفارش واقعی هنوز به Backend نیاز دارد.
