
import 'package:flutter/material.dart';

void main() => runApp(const BazaarManApp());

class Product {
  final String name, category, price, image;
  final double rating;
  Product(this.name, this.category, this.price, this.image, this.rating);
}

final products = [
  Product('آیفون 15 پرو مکس', 'موبایل', '89,900,000', '📱', 4.8),
  Product('ساعت هوشمند', 'دیجیتال', '1,250,000', '⌚', 4.5),
  Product('کفش ورزشی', 'پوشاک', '950,000', '👟', 4.3),
  Product('عطر مردانه', 'آرایشی', '650,000', '🧴', 4.6),
  Product('هدفون بی‌سیم', 'دیجیتال', '2,350,000', '🎧', 4.7),
  Product('کوله پشتی', 'پوشاک', '1,180,000', '🎒', 4.4),
];

class BazaarManApp extends StatelessWidget {
  const BazaarManApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بازار من',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF6B1A)),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final cart = <Product>[];

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(onAdd: (p) => setState(() => cart.add(p))),
      CategoriesTab(onAdd: (p) => setState(() => cart.add(p))),
      CartTab(cart: cart, onRemove: (p) => setState(() => cart.remove(p))),
      const OrdersTab(),
      const ProfileTab(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[tab]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'دسته‌ها'),
            NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'سبد خرید'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'سفارش‌ها'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حساب من'),
          ],
        ),
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  final void Function(Product) onAdd;
  const HomeTab({super.key, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          const CircleAvatar(child: Icon(Icons.shopping_bag)),
          const SizedBox(width: 10),
          const Expanded(child: Text('بازار من', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ]),
        const SizedBox(height: 14),
        TextField(
          decoration: InputDecoration(
            hintText: 'جستجو در محصولات...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          height: 150,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF5B2EFF), Color(0xFF7C3AED)]),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('تخفیف ویژه', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('تا ۳۰٪ تخفیف روی محصولات منتخب', style: TextStyle(color: Colors.white, fontSize: 16)),
              Spacer(),
              Text('همین حالا خرید کنید ←', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('دسته‌بندی‌ها', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SizedBox(
          height: 90,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: ['📱 موبایل', '👕 لباس', '🏠 خانه', '💄 آرایشی', '👟 کفش', '📚 کتاب']
                .map((x) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Center(child: Text(x)))))
                .toList(),
          ),
        ),
        const SizedBox(height: 16),
        const Text('پیشنهاد ویژه', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: products.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .72,
          ),
          itemBuilder: (_, i) => ProductCard(product: products[i], onAdd: onAdd),
        ),
      ],
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final void Function(Product) onAdd;
  const ProductCard({super.key, required this.product, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductPage(product: product, onAdd: onAdd))),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(14)),
                child: Center(child: Text(product.image, style: const TextStyle(fontSize: 58))),
              ),
            ),
            const SizedBox(height: 8),
            Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('${product.price} تومان', style: const TextStyle(fontWeight: FontWeight.w600)),
            Row(children: [const Icon(Icons.star, size: 16, color: Colors.amber), Text(' ${product.rating}')]),
            Align(
              alignment: Alignment.centerLeft,
              child: IconButton.filled(onPressed: () { onAdd(product); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('به سبد خرید اضافه شد'))); }, icon: const Icon(Icons.add_shopping_cart)),
            )
          ]),
        ),
      ),
    );
  }
}

class ProductPage extends StatelessWidget {
  final Product product;
  final void Function(Product) onAdd;
  const ProductPage({super.key, required this.product, required this.onAdd});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('جزئیات محصول')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(height: 260, decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(24)), child: Center(child: Text(product.image, style: const TextStyle(fontSize: 110)))),
        const SizedBox(height: 18),
        Text(product.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        Text('${product.price} تومان', style: TextStyle(fontSize: 20, color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text('⭐ ${product.rating}   •   موجود در انبار', style: const TextStyle(fontSize: 15)),
        const SizedBox(height: 18),
        const Text('توضیحات محصول', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const Text('محصول با کیفیت و مناسب برای استفاده روزمره. جزئیات، مشخصات و شرایط ضمانت در این بخش قابل نمایش است.'),
        const SizedBox(height: 28),
        FilledButton.icon(onPressed: () { onAdd(product); Navigator.pop(context); }, icon: const Icon(Icons.shopping_cart), label: const Text('افزودن به سبد خرید')),
        OutlinedButton(onPressed: () {}, child: const Text('خرید فوری')),
      ]),
    ),
  );
}

class CategoriesTab extends StatelessWidget {
  final void Function(Product) onAdd;
  const CategoriesTab({super.key, required this.onAdd});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('دسته‌بندی‌ها', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      ...['موبایل و تبلت','لباس و پوشاک','کفش','خانه و آشپزخانه','آرایشی و بهداشتی','کتاب و لوازم تحریر','ورزش و سفر','کودک و نوزاد']
        .map((x) => Card(child: ListTile(leading: const Icon(Icons.category_outlined), title: Text(x), trailing: const Icon(Icons.chevron_left)))),
    ],
  );
}

class CartTab extends StatelessWidget {
  final List<Product> cart;
  final void Function(Product) onRemove;
  const CartTab({super.key, required this.cart, required this.onRemove});
  @override
  Widget build(BuildContext context) {
    final total = cart.length * 1000000;
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('سبد خرید', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (cart.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('سبد خرید شما خالی است'))),
      ...cart.map((p) => Card(child: ListTile(
        leading: Text(p.image, style: const TextStyle(fontSize: 32)),
        title: Text(p.name),
        subtitle: Text('${p.price} تومان'),
        trailing: IconButton(onPressed: () => onRemove(p), icon: const Icon(Icons.delete_outline)),
      ))),
      if (cart.isNotEmpty) ...[
        const Divider(),
        Text('مجموع تقریبی: $total تومان', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 12),
        FilledButton(onPressed: () {}, child: const Text('ثبت سفارش')),
      ]
    ]);
  }
}

class OrdersTab extends StatelessWidget {
  const OrdersTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('سفارش‌های من', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    Card(child: ListTile(leading: const Icon(Icons.local_shipping_outlined), title: const Text('سفارش #12345'), subtitle: const Text('در حال ارسال • ۲,۴۵۰,۰۰۰ تومان'), trailing: const Icon(Icons.chevron_left))),
    Card(child: ListTile(leading: const Icon(Icons.check_circle_outline), title: const Text('سفارش #12321'), subtitle: const Text('تحویل داده شد • ۱,۲۰۰,۰۰۰ تومان'), trailing: const Icon(Icons.chevron_left))),
  ]);
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('حساب کاربری', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 20),
    const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
    const SizedBox(height: 10),
    const Center(child: Text('احمد محمدی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
    const Center(child: Text('۰۷۹۱۲۳۴۵۶۷۸')),
    const SizedBox(height: 20),
    ...['اطلاعات شخصی','آدرس‌های من','کیف پول من','علاقه‌مندی‌ها','اعلان‌ها','زبان برنامه','تنظیمات']
      .map((x) => Card(child: ListTile(title: Text(x), trailing: const Icon(Icons.chevron_left)))),
    const SizedBox(height: 10),
    OutlinedButton(onPressed: () {}, child: const Text('خروج از حساب')),
  ]);
}
