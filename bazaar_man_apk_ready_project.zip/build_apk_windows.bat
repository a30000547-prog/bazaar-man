@echo off
echo ==========================================
echo بازار من - آماده سازی و ساخت APK
echo ==========================================
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter پيدا نشد. Flutter SDK را نصب کنيد.
  pause
  exit /b 1
)

flutter create . --platforms=android --org com.bazaar.man
if errorlevel 1 exit /b 1

flutter pub get
if errorlevel 1 exit /b 1

flutter build apk --release
if errorlevel 1 exit /b 1

echo.
echo APK ساخته شد:
echo build\app\outputs\flutter-apk\app-release.apk
pause
